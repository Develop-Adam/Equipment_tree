@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start http://127.0.0.1:8000
  py server.py
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  start http://127.0.0.1:8000
  python server.py
  goto :eof
)
echo Python was not found on PATH.
pause
