// This object stores all of the app's current data while it is running.
const state = {
  // List of buildings loaded from buildings.json
  buildings: [],

  // Static equipment data loaded from equipment.json
  equipment: {},

  // Live equipment data loaded from /api/state
  liveState: {},

  // The ID of the building currently being viewed
  currentBuildingId: null,

  // The currently selected equipment key
  // Example: "building-1::machine-2"
  selectedEquipmentKey: null,

  // The currently loaded root SVG element
  svgRoot: null,

  // Stores the timer used for polling live data
  pollHandle: null,

  // Used to tell the difference between a click and a drag on the map
  isMapDragging: false
};

// App settings and URLs used in one place so they are easy to change later.
const CONFIG = {
  buildingsUrl: './data/buildings.json',
  equipmentUrl: './data/equipment.json',
  liveStateUrl: '/api/state',
  pollMs: 1000 // how often to refresh live data, in milliseconds
};

// Wait until the page is fully loaded before starting the app.
document.addEventListener('DOMContentLoaded', async () => {
  await initializeApp();
});

// Main startup function
async function initializeApp() {
  try {
    // Load building list and equipment metadata from JSON files
    state.buildings = await fetchJson(CONFIG.buildingsUrl);
    state.equipment = await fetchJson(CONFIG.equipmentUrl);

    // Create the building buttons in the UI
    renderBuildingList();

    // If there is at least one building, automatically load the first one
    if (state.buildings.length > 0) {
      await loadBuilding(state.buildings[0].id);
    }

    // Start polling the backend for live equipment data
    startLivePolling();
  } catch (error) {
    console.error('App initialization failed:', error);

    // Show the UI as offline if startup fails
    setConnectionStatus('offline', 'Startup failed');
  }
}

// Generic helper to fetch JSON from a URL
async function fetchJson(url) {
  // cache: 'no-store' forces the browser to fetch fresh data every time
  const response = await fetch(url, { cache: 'no-store' });

  // If request failed, throw an error
  if (!response.ok) throw new Error(`Failed to fetch ${url}: ${response.status}`);

  // Convert the response into JavaScript data
  return await response.json();
}

// Create a button for each building
function renderBuildingList() {
  const container = document.getElementById('building-list');
  if (!container) return;

  // Clear old buttons before rebuilding the list
  container.innerHTML = '';

  state.buildings.forEach((building) => {
    const btn = document.createElement('button');
    btn.className = 'building-button';
    btn.textContent = building.name;
    btn.dataset.buildingId = building.id;

    // Load this building when clicked
    btn.addEventListener('click', async () => loadBuilding(building.id));

    container.appendChild(btn);
  });

  // Update which building button is marked active
  updateBuildingSelectionUi();
}

// Highlight the currently selected building button
function updateBuildingSelectionUi() {
  document.querySelectorAll('.building-button').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.buildingId === state.currentBuildingId);
  });
}

// Load a building's SVG and prepare the viewer
async function loadBuilding(buildingId) {
  const building = state.buildings.find((b) => b.id === buildingId);
  if (!building) return;

  // Save current building info
  state.currentBuildingId = buildingId;

  // Clear any selected equipment when changing buildings
  state.selectedEquipmentKey = null;

  // Update sidebar button styles
  updateBuildingSelectionUi();

  const mapHost = document.getElementById('map-host');
  const title = document.getElementById('viewer-title');
  const subtitle = document.getElementById('viewer-subtitle');

  try {
    // Load raw SVG text
    const svgText = await fetchSvg(building.svg);

    // Put the SVG markup into the page
    mapHost.innerHTML = svgText;

    // Get the root <svg> element from the inserted markup
    const svg = mapHost.querySelector('svg');
    if (!svg) throw new Error(`No <svg> found in ${building.svg}`);

    state.svgRoot = svg;

    // Update viewer text
    title.textContent = building.name;
    subtitle.textContent = 'Drag empty space to pan. Scroll to zoom. Press F to refit.';

    // Prepare the SVG for display and interaction
    prepareSvg(svg);
    wireSvgInteractivity(svg, buildingId);

    // Apply live colors/status to the SVG nodes
    applyLiveStateToCurrentSvg();

    // Reset the right-side details panel
    resetDetailsPanel();

    // Fit the whole SVG nicely into view
    fitSvgToView(svg);
  } catch (error) {
    console.error('Failed to load building', error);

    // Show an error inside the map area
    mapHost.innerHTML = `<div class="map-error">Failed to load SVG for ${escapeHtml(building.name)}</div>`;
    title.textContent = building.name;
    subtitle.textContent = 'Unable to load SVG.';
  }
}

// Fetch an SVG file as text
async function fetchSvg(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Failed to fetch SVG ${url}: ${response.status}`);
  return await response.text();
}

// Set up the SVG so it behaves nicely in the page
function prepareSvg(svg) {
  // Make the SVG not tabbable in normal keyboard navigation
  svg.setAttribute('tabindex', '-1');

  // Make it fill the viewer container
  svg.style.width = '100%';
  svg.style.height = '100%';
  svg.style.display = 'block';

  // If the SVG does not already have a viewBox, create one from its content bounds
  if (!svg.getAttribute('viewBox')) {
    const bbox = svg.getBBox();
    svg.setAttribute('viewBox', `${bbox.x} ${bbox.y} ${bbox.width} ${bbox.height}`);
  }
}

// Add click, pan, and zoom behavior to the SVG
function wireSvgInteractivity(svg, buildingId) {
  // Turn on map panning and zooming
  enablePanZoom(svg);

  // Find SVG elements that should act like clickable equipment
  const clickable = getClickableSvgElements(svg, buildingId);

  clickable.forEach((el) => {
    el.classList.add('equipment-node');
    el.style.cursor = 'pointer';

    // When user clicks a piece of equipment
    el.addEventListener('click', (event) => {
      // Ignore the click if the user was dragging the map
      if (state.isMapDragging) return;

      event.stopPropagation();

      const elementId = getElementId(el);
      const equipmentKey = makeEquipmentKey(buildingId, elementId);

      // Save selected equipment
      state.selectedEquipmentKey = equipmentKey;

      // Highlight it in the SVG
      highlightSelectedElement(svg, elementId);

      // Show details in the side panel
      updateDetailsPanel(equipmentKey, elementId);
    });
  });

  // Clicking the empty SVG background clears selection
  svg.addEventListener('click', (event) => {
    if (event.target === svg) {
      state.selectedEquipmentKey = null;
      clearSelectedHighlight(svg);
      resetDetailsPanel();
    }
  });
}

// Find which SVG elements should be clickable
function getClickableSvgElements(svg, buildingId) {
  const prefix = `${buildingId}::`;

  return Array.from(svg.querySelectorAll('g[data-cell-id]')).filter((el) => {
    const elementId = el.getAttribute('data-cell-id');

    // Ignore missing or invalid IDs
    if (!elementId || elementId === '0' || elementId === '1') return false;

    // Only include SVG nodes that exist in equipment.json
    if (!state.equipment[`${prefix}${elementId}`]) return false;

    // Only include elements that actually contain a visible shape
    return Boolean(el.querySelector('rect, ellipse, path, polygon'));
  });
}

// Get the element's ID from the SVG
function getElementId(el) {
  return el.getAttribute('data-cell-id') || el.id || '';
}

// Build a unique key for one equipment item
function makeEquipmentKey(buildingId, elementId) {
  return `${buildingId}::${elementId}`;
}

// Get static metadata for an equipment item
function getStaticEquipment(equipmentKey) {
  return state.equipment[equipmentKey] || null;
}

// Get live data for an equipment item
function getLiveEquipment(equipmentKey) {
  return state.liveState[equipmentKey] || null;
}

// Fill the details panel with information for the selected equipment
function updateDetailsPanel(equipmentKey, elementId = null) {
  const panel = document.getElementById('details-panel');
  if (!panel) return;

  // Static data comes from equipment.json
  const staticData = getStaticEquipment(equipmentKey) || {};

  // Live data comes from /api/state
  const liveData = getLiveEquipment(equipmentKey) || {};

  // Use static data first, then fallback values if missing
  const title = staticData.name || staticData.label || readableIdFromKey(equipmentKey);
  const type = staticData.type || 'Equipment';
  const description = staticData.description || 'No description';
  const status = liveData.status || staticData.status || 'unknown';
  const alarmText = liveData.alarm_text || '';
  const lastUpdate = liveData.last_update || 'N/A';

  // Build a list of any extra live values
  // Skip fields that are already shown separately above
  const liveFields = Object.entries(liveData)
    .filter(([key]) => !['status', 'alarm', 'alarm_text', 'last_update'].includes(key))
    .map(([key, value]) => `<div class="detail-row"><span class="detail-key">${escapeHtml(key)}</span><span class="detail-value">${escapeHtml(String(value))}</span></div>`)
    .join('');

  panel.innerHTML = `
    <div class="details-header">
      <h2>${escapeHtml(title)}</h2>
      <div class="status-pill">${escapeHtml(status)}</div>
    </div>
    <div class="detail-row"><span class="detail-key">Type</span><span class="detail-value">${escapeHtml(type)}</span></div>
    <div class="detail-row"><span class="detail-key">SVG ID</span><span class="detail-value">${escapeHtml(elementId || readableIdFromKey(equipmentKey))}</span></div>
    <div class="detail-row"><span class="detail-key">Data Key</span><span class="detail-value">${escapeHtml(equipmentKey)}</span></div>
    <div class="detail-row"><span class="detail-key">Description</span><span class="detail-value">${escapeHtml(description)}</span></div>
    <div class="detail-row"><span class="detail-key">Last Update</span><span class="detail-value">${escapeHtml(lastUpdate)}</span></div>
    ${alarmText ? `<div class="detail-row"><span class="detail-key">Alarm</span><span class="detail-value">${escapeHtml(alarmText)}</span></div>` : ''}
    <div class="details-section-title">Live Values</div>
    ${liveFields || `<div class="detail-empty">No live values</div>`}
  `;
}

// Reset the details panel when nothing is selected
function resetDetailsPanel() {
  const panel = document.getElementById('details-panel');
  if (!panel) return;

  panel.innerHTML = `
    <div class="details-placeholder">
      <h2>Select Equipment</h2>
      <p>Click an item in the map to view details.</p>
    </div>
  `;
}

// Convert "building-1::pump-3" into just "pump-3"
function readableIdFromKey(equipmentKey) {
  const parts = equipmentKey.split('::');
  return parts[1] || equipmentKey;
}

// Start repeatedly polling the backend for live state updates
function startLivePolling() {
  // If polling already exists, stop it first
  if (state.pollHandle) clearInterval(state.pollHandle);

  // Poll once immediately so user gets data right away
  pollLiveState();

  // Then keep polling every CONFIG.pollMs
  state.pollHandle = setInterval(pollLiveState, CONFIG.pollMs);
}

// Ask the backend for fresh live state data
async function pollLiveState() {
  try {
    const live = await fetchJson(CONFIG.liveStateUrl);
    state.liveState = live || {};

    // Show online status in the UI
    setConnectionStatus('online', 'Live');

    // Update SVG colors/classes based on new live data
    applyLiveStateToCurrentSvg();

    // If something is selected, refresh its details panel too
    if (state.selectedEquipmentKey) {
      const id = state.selectedEquipmentKey.split('::')[1];
      updateDetailsPanel(state.selectedEquipmentKey, id);
    }
  } catch (error) {
    console.error('Live state poll failed:', error);

    // Show disconnected status if polling fails
    setConnectionStatus('offline', 'Disconnected');
  }
}

// Apply live status classes to equipment nodes in the currently visible SVG
function applyLiveStateToCurrentSvg() {
  if (!state.svgRoot || !state.currentBuildingId) return;

  const clickable = getClickableSvgElements(state.svgRoot, state.currentBuildingId);

  clickable.forEach((el) => {
    // Remove old status styles first
    clearStatusClasses(el);

    const equipmentKey = makeEquipmentKey(state.currentBuildingId, getElementId(el));
    const liveData = getLiveEquipment(equipmentKey);
    const staticData = getStaticEquipment(equipmentKey);

    // Use live status first, then static status, then unknown
    const status = (liveData && liveData.status) || (staticData && staticData.status) || 'unknown';

    applyStatusClass(el, status);
  });

  // Re-apply selected highlight after statuses are updated
  if (state.selectedEquipmentKey) {
    highlightSelectedElement(state.svgRoot, state.selectedEquipmentKey.split('::')[1]);
  }
}

// Remove all possible status-related classes from an element
function clearStatusClasses(el) {
  el.classList.remove('status-running','status-idle','status-stopped','status-alarm','status-warning','status-offline','status-unknown','selected-equipment');
}

// Add the correct CSS class for the equipment's current status
function applyStatusClass(el, status) {
  switch ((status || '').toLowerCase()) {
    case 'running':
      el.classList.add('status-running');
      break;
    case 'idle':
      el.classList.add('status-idle');
      break;
    case 'stopped':
      el.classList.add('status-stopped');
      break;
    case 'alarm':
      el.classList.add('status-alarm');
      break;
    case 'warning':
      el.classList.add('status-warning');
      break;
    case 'offline':
      el.classList.add('status-offline');
      break;
    default:
      el.classList.add('status-unknown');
      break;
  }
}

// Highlight the selected equipment in the SVG
function highlightSelectedElement(svg, selectedId) {
  // Clear old selection first
  clearSelectedHighlight(svg);

  // Find the matching <g> element by its data-cell-id
  const target = svg.querySelector(`g[data-cell-id="${cssEscape(selectedId)}"]`);

  if (target) target.classList.add('selected-equipment');
}

// Remove selection highlight from all elements
function clearSelectedHighlight(svg) {
  svg.querySelectorAll('.selected-equipment').forEach((el) => el.classList.remove('selected-equipment'));
}

// Update the connection status text in the UI
function setConnectionStatus(mode, text) {
  const indicator = document.getElementById('connection-status');
  if (!indicator) return;

  indicator.textContent = text;
  indicator.className = `connection-status ${mode}`;
}

// Add panning and zooming behavior to the SVG
function enablePanZoom(svg) {
  let isDragging = false;
  let startX = 0;
  let startY = 0;

  // Read the starting viewBox from the SVG
  let viewBox = parseViewBox(svg);

  // Start dragging when mouse is pressed on empty map space
  svg.addEventListener('mousedown', (event) => {
    const clickedInteractive = event.target.closest('g[data-cell-id]');

    // Do not start map dragging if user clicked equipment
    if (clickedInteractive) return;

    isDragging = true;
    state.isMapDragging = false;
    startX = event.clientX;
    startY = event.clientY;
  });

  // Pan the map while mouse is moving
  window.addEventListener('mousemove', (event) => {
    if (!isDragging) return;

    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    // If mouse moved enough, treat it as dragging instead of clicking
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) state.isMapDragging = true;

    // Convert mouse movement into SVG coordinate movement
    const scaleX = viewBox.width / svg.clientWidth;
    const scaleY = viewBox.height / svg.clientHeight;

    viewBox.x -= dx * scaleX;
    viewBox.y -= dy * scaleY;

    setViewBox(svg, viewBox);

    // Save current position for next move event
    startX = event.clientX;
    startY = event.clientY;
  });

  // Stop dragging when mouse button is released
  window.addEventListener('mouseup', () => {
    isDragging = false;

    // Small timeout lets click events finish before resetting drag flag
    setTimeout(() => { state.isMapDragging = false; }, 0);
  });

  // Zoom the SVG using mouse wheel
  svg.addEventListener('wheel', (event) => {
    event.preventDefault();

    const viewBoxNow = parseViewBox(svg);

    // Scroll down = zoom out, scroll up = zoom in
    const zoomFactor = event.deltaY > 0 ? 1.1 : 0.9;

    // Find the mouse position in SVG coordinates
    const point = clientToSvgPoint(svg, event.clientX, event.clientY, viewBoxNow);

    const newWidth = viewBoxNow.width * zoomFactor;
    const newHeight = viewBoxNow.height * zoomFactor;

    // Adjust x/y so the zoom centers around the mouse pointer
    viewBox = {
      x: point.x - ((point.x - viewBoxNow.x) / viewBoxNow.width) * newWidth,
      y: point.y - ((point.y - viewBoxNow.y) / viewBoxNow.height) * newHeight,
      width: newWidth,
      height: newHeight
    };

    setViewBox(svg, viewBox);
  }, { passive: false });

  // Press "f" to refit the SVG to the view
  window.addEventListener('keydown', (event) => {
    if (event.key.toLowerCase() === 'f' && state.svgRoot === svg) {
      fitSvgToView(svg);
      viewBox = parseViewBox(svg);
    }
  });
}

// Read the current viewBox from the SVG
function parseViewBox(svg) {
  const raw = svg.getAttribute('viewBox');

  // If no viewBox exists, create one from the SVG content size
  if (!raw) {
    const bbox = svg.getBBox();
    return { x: bbox.x, y: bbox.y, width: bbox.width, height: bbox.height };
  }

  const [x, y, width, height] = raw.split(/\s+/).map(Number);
  return { x, y, width, height };
}

// Write a new viewBox to the SVG
function setViewBox(svg, vb) {
  svg.setAttribute('viewBox', `${vb.x} ${vb.y} ${vb.width} ${vb.height}`);
}

// Reset the SVG view so the whole drawing fits nicely
function fitSvgToView(svg) {
  const bbox = svg.getBBox();
  const padding = 40;

  svg.setAttribute(
    'viewBox',
    `${bbox.x - padding} ${bbox.y - padding} ${bbox.width + padding * 2} ${bbox.height + padding * 2}`
  );
}

// Convert mouse position on the screen into SVG coordinate space
function clientToSvgPoint(svg, clientX, clientY, viewBox) {
  const rect = svg.getBoundingClientRect();
  const xRatio = (clientX - rect.left) / rect.width;
  const yRatio = (clientY - rect.top) / rect.height;

  return {
    x: viewBox.x + xRatio * viewBox.width,
    y: viewBox.y + yRatio * viewBox.height
  };
}

// Escape HTML special characters so text is safe to insert into innerHTML
function escapeHtml(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

// Escape a value so it is safe to use inside a CSS selector
function cssEscape(value) {
  // Use the browser's built-in escape if available
  if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);

  // Fallback escape for older browsers
  return String(value).replace(/([ #;?%&,.+*~':"!^$[\]()=>|/@])/g, '\\$1');
}