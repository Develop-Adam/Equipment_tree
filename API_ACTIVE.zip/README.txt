Equipment Viewer - Modular Rev 2 API

What is included:
- Modular multi-building SVG viewer
- ID-based equipment mapping using draw.io SVG data-cell-id values
- A small Python server that serves both the site and /api/state
- POST support on /api/state so you can test with Postman or Insomnia

Quick start:
1. Open this folder.
2. Double-click start_app.bat
3. Browser opens to http://127.0.0.1:8000

API endpoints:
- GET  http://127.0.0.1:8000/api/state
  Returns the current live state from data/live_state.json

- POST http://127.0.0.1:8000/api/state
  Replaces the current live state with your JSON body

Example POST body:
{
  "building_2::qB1-vgkHPpZSQpjzEzUW-9": {
    "status": "alarm",
    "alarm": true,
    "alarm_text": "Overtravel fault",
    "part_count": 155,
    "last_update": "2026-03-19T20:30:00Z"
  },
  "building_3::qB1-vgkHPpZSQpjzEzUW-53": {
    "status": "running",
    "alarm": false,
    "temperature": 143.6,
    "part_count": 889,
    "last_update": "2026-03-19T20:30:00Z"
  }
}

How the keys work:
- Format: building_id::svg_cell_id
- Example: building_2::qB1-vgkHPpZSQpjzEzUW-9
- The right panel shows both the SVG ID and the full data key when you click an item

Files you will edit most:
- data/buildings.json     -> add buildings
- data/equipment.json     -> static metadata for right panel
- data/live_state.json    -> current live values (the server also rewrites this on POST)
- svg/*.svg               -> layout files from draw.io
- assets/app.js           -> viewer behavior
- assets/style.css        -> styling

Adding a new building:
1. Export a new SVG into svg/
2. Add a row to data/buildings.json
3. Add matching equipment entries to data/equipment.json

Notes:
- This version colors nodes from live status values returned by /api/state
- Status values currently recognized: running, idle, stopped, alarm, warning, offline
- Browser page scrolling is disabled so panning stays inside the map
