
import json
import mimetypes
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote

BASE_DIR = Path(__file__).resolve().parent
LIVE_STATE_FILE = BASE_DIR / 'data' / 'live_state.json'
PORT = 8000

class AppHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def translate_path(self, path):
        path = path.split('?', 1)[0].split('#', 1)[0]
        path = unquote(path)
        if path == '/':
            path = '/index.html'
        full = (BASE_DIR / path.lstrip('/')).resolve()
        if BASE_DIR not in full.parents and full != BASE_DIR:
            return str(BASE_DIR / 'index.html')
        return str(full)

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith('/api/state'):
            self.handle_get_state()
            return
        return super().do_GET()

    def do_POST(self):
        if self.path.startswith('/api/state'):
            self.handle_post_state()
            return
        self.send_error(404, 'Unknown API endpoint')

    def handle_get_state(self):
        try:
            payload = json.loads(LIVE_STATE_FILE.read_text(encoding='utf-8'))
        except FileNotFoundError:
            payload = {}
        except json.JSONDecodeError as exc:
            self.send_json({"error": f"Invalid live_state.json: {exc}"}, status=500)
            return
        self.send_json(payload)

    def handle_post_state(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = 0
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode('utf-8') if raw else '{}')
        except json.JSONDecodeError as exc:
            self.send_json({"error": f"Invalid JSON: {exc}"}, status=400)
            return
        LIVE_STATE_FILE.write_text(json.dumps(payload, indent=2), encoding='utf-8')
        self.send_json({"ok": True, "saved": True, "entries": len(payload)})

    def send_json(self, payload, status=200):
        body = json.dumps(payload, indent=2).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == '__main__':
    mimetypes.add_type('image/svg+xml', '.svg')
    server = ThreadingHTTPServer(('127.0.0.1', PORT), AppHandler)
    print(f'Serving app on http://127.0.0.1:{PORT}')
    print('GET  /api/state  -> current live state')
    print('POST /api/state  -> replace live state JSON')
    server.serve_forever()
