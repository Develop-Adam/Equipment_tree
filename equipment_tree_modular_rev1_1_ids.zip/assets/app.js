const state = {
  buildings: [],
  equipment: {},
  activeBuildingId: null,
  activeBuilding: null,
  activeSvg: null,
  panZoom: null,
  selectedNode: null,
};

const els = {
  buildingList: document.getElementById('buildingList'),
  viewerTitle: document.getElementById('viewerTitle'),
  viewerSubtitle: document.getElementById('viewerSubtitle'),
  mapViewport: document.getElementById('mapViewport'),
  detailsContent: document.getElementById('detailsContent'),
};

document.addEventListener('DOMContentLoaded', init);

async function init() {
  const [buildings, equipment] = await Promise.all([
    fetchJson('data/buildings.json'),
    fetchJson('data/equipment.json'),
  ]);

  state.buildings = buildings;
  state.equipment = equipment;
  renderBuildingButtons();

  if (state.buildings.length) {
    await loadBuilding(state.buildings[0].id);
  } else {
    els.viewerTitle.textContent = 'No buildings configured';
  }
}

async function fetchJson(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error(`Failed to load ${path}`);
  return await response.json();
}

function renderBuildingButtons() {
  els.buildingList.innerHTML = '';
  for (const building of state.buildings) {
    const button = document.createElement('button');
    button.className = 'building-button';
    button.textContent = building.name;
    button.dataset.buildingId = building.id;
    button.addEventListener('click', () => loadBuilding(building.id));
    els.buildingList.appendChild(button);
  }
  syncActiveBuildingButton();
}

function syncActiveBuildingButton() {
  for (const button of els.buildingList.querySelectorAll('.building-button')) {
    button.classList.toggle('active', button.dataset.buildingId === state.activeBuildingId);
  }
}

async function loadBuilding(buildingId) {
  const building = state.buildings.find(b => b.id === buildingId);
  if (!building) return;

  state.activeBuildingId = building.id;
  state.activeBuilding = building;
  state.selectedNode = null;
  syncActiveBuildingButton();

  const response = await fetch(building.svg);
  if (!response.ok) throw new Error(`Failed to load ${building.svg}`);
  const svgText = await response.text();

  els.mapViewport.innerHTML = svgText;
  const svg = els.mapViewport.querySelector('svg');
  if (!svg) {
    els.viewerTitle.textContent = building.name;
    els.viewerSubtitle.textContent = 'SVG did not contain a root <svg> element.';
    return;
  }

  state.activeSvg = svg;
  prepareSvg(svg);
  makeInteractive(svg);
  state.panZoom = enablePanZoom(svg, els.mapViewport);
  refit();
  showBuildingDetails(building);

  els.viewerTitle.textContent = building.name;
  els.viewerSubtitle.textContent = `${building.svg} · ID-based node mapping enabled`;
}

function prepareSvg(svg) {
  svg.removeAttribute('width');
  svg.removeAttribute('height');
  svg.style.background = 'transparent';
  const bg = svg.querySelector('rect[width="100%"][height="100%"]');
  if (bg) bg.classList.add('svg-root-bg');
}

function makeInteractive(svg) {
  const groups = Array.from(svg.querySelectorAll('g[data-cell-id], g[id]'));
  for (const group of groups) {
    if (!isClickableNode(group)) continue;

    const nodeId = getNodeId(group);
    const label = getNodeLabel(group);
    if (!nodeId) continue;

    group.classList.add('equipment-node');
    group.dataset.nodeId = nodeId;
    group.dataset.label = label || nodeId;
    group.tabIndex = -1;

    group.addEventListener('click', event => {
      event.stopPropagation();
      selectNode(group);
    });
  }

  svg.addEventListener('click', () => clearSelection());
}

function isClickableNode(group) {
  return !!group.querySelector('rect, ellipse, polygon');
}

function getNodeId(group) {
  const cellId = group.getAttribute('data-cell-id');
  if (cellId && cellId !== '0' && cellId !== '1') return cellId;
  const id = group.getAttribute('id');
  if (id && id !== '0' && id !== '1') return id;
  return '';
}

function getNodeLabel(group) {
  const foreignDiv = group.querySelector('foreignObject div div div');
  if (foreignDiv && foreignDiv.textContent.trim()) return foreignDiv.textContent.trim();
  const textNode = group.querySelector('text');
  if (textNode && textNode.textContent.trim()) return textNode.textContent.trim();
  return '';
}

function selectNode(group) {
  if (state.selectedNode) {
    state.selectedNode.classList.remove('selected');
  }
  state.selectedNode = group;
  group.classList.add('selected');
  showNodeDetails(group.dataset.nodeId, group.dataset.label || group.dataset.nodeId);
}

function clearSelection() {
  if (state.selectedNode) state.selectedNode.classList.remove('selected');
  state.selectedNode = null;
  showBuildingDetails(state.activeBuilding);
}

function metadataKey(buildingId, nodeId) {
  return `${buildingId}::${nodeId}`;
}

function showBuildingDetails(building) {
  if (!building) return;
  els.detailsContent.innerHTML = `
    <dl class="detail-grid">
      <dt>Name</dt><dd>${escapeHtml(building.name)}</dd>
      <dt>Type</dt><dd>Building</dd>
      <dt>SVG</dt><dd>${escapeHtml(building.svg)}</dd>
      <dt>Notes</dt><dd>Node metadata is now keyed by SVG element ID, not visible text.</dd>
    </dl>
    <div class="code-note">Tip: add a building by dropping a new SVG into <code>svg/</code>, adding one row to <code>data/buildings.json</code>, and then adding node entries to <code>data/equipment.json</code> using the SVG IDs.</div>
  `;
}

function showNodeDetails(nodeId, label) {
  const key = metadataKey(state.activeBuildingId, nodeId);
  const meta = state.equipment[key] || {
    name: label,
    type: inferType(label),
    status: 'Unknown',
    description: 'No custom metadata yet. Add this key to data/equipment.json.',
  };

  els.detailsContent.innerHTML = `
    <dl class="detail-grid">
      <dt>Name</dt><dd>${escapeHtml(meta.name || label)}</dd>
      <dt>Label</dt><dd>${escapeHtml(label)}</dd>
      <dt>Type</dt><dd>${escapeHtml(meta.type || '')}</dd>
      <dt>Status</dt><dd>${escapeHtml(meta.status || '')}</dd>
      <dt>Description</dt><dd>${escapeHtml(meta.description || '')}</dd>
      <dt>SVG ID</dt><dd><code>${escapeHtml(nodeId)}</code></dd>
      <dt>Data key</dt><dd><code>${escapeHtml(key)}</code></dd>
    </dl>
    <div class="code-note">Use the SVG ID above as the stable key in <code>data/equipment.json</code>. Visible labels can now change without breaking the metadata link.</div>
  `;
}

function inferType(label) {
  const lower = String(label).toLowerCase();
  if (lower.includes('building')) return 'Building';
  if (lower.includes('pallet')) return 'Pallet';
  if (lower.includes('tool') || /^t\d+$/.test(lower)) return 'Tooling';
  if (lower.includes('part')) return 'Parts';
  return 'Equipment';
}

function enablePanZoom(svg, viewport) {
  let vb = svg.viewBox && svg.viewBox.baseVal && svg.viewBox.baseVal.width
    ? { x: svg.viewBox.baseVal.x, y: svg.viewBox.baseVal.y, width: svg.viewBox.baseVal.width, height: svg.viewBox.baseVal.height }
    : deriveViewBox(svg);

  applyViewBox(svg, vb);

  const panZoom = {
    viewBox: vb,
    isDragging: false,
    lastX: 0,
    lastY: 0,
  };

  viewport.onwheel = event => {
    event.preventDefault();
    const scale = event.deltaY > 0 ? 1.1 : 0.9;
    const rect = viewport.getBoundingClientRect();
    const px = (event.clientX - rect.left) / rect.width;
    const py = (event.clientY - rect.top) / rect.height;

    const newWidth = panZoom.viewBox.width * scale;
    const newHeight = panZoom.viewBox.height * scale;
    panZoom.viewBox.x += (panZoom.viewBox.width - newWidth) * px;
    panZoom.viewBox.y += (panZoom.viewBox.height - newHeight) * py;
    panZoom.viewBox.width = newWidth;
    panZoom.viewBox.height = newHeight;
    applyViewBox(svg, panZoom.viewBox);
  };

  viewport.onpointerdown = event => {
    if (event.target.closest('.equipment-node')) return;
    panZoom.isDragging = true;
    panZoom.lastX = event.clientX;
    panZoom.lastY = event.clientY;
    viewport.setPointerCapture(event.pointerId);
  };

  viewport.onpointermove = event => {
    if (!panZoom.isDragging) return;
    const rect = viewport.getBoundingClientRect();
    const dx = (event.clientX - panZoom.lastX) * (panZoom.viewBox.width / rect.width);
    const dy = (event.clientY - panZoom.lastY) * (panZoom.viewBox.height / rect.height);
    panZoom.viewBox.x -= dx;
    panZoom.viewBox.y -= dy;
    panZoom.lastX = event.clientX;
    panZoom.lastY = event.clientY;
    applyViewBox(svg, panZoom.viewBox);
  };

  const endDrag = event => {
    panZoom.isDragging = false;
    try { viewport.releasePointerCapture(event.pointerId); } catch (_) {}
  };
  viewport.onpointerup = endDrag;
  viewport.onpointercancel = endDrag;
  viewport.onpointerleave = endDrag;

  return panZoom;
}

function deriveViewBox(svg) {
  const vbAttr = svg.getAttribute('viewBox');
  if (vbAttr) {
    const [x, y, width, height] = vbAttr.split(/\s+/).map(Number);
    return { x, y, width, height };
  }
  const width = Number.parseFloat(svg.getAttribute('width')) || 1000;
  const height = Number.parseFloat(svg.getAttribute('height')) || 800;
  return { x: 0, y: 0, width, height };
}

function applyViewBox(svg, vb) {
  svg.setAttribute('viewBox', `${vb.x} ${vb.y} ${vb.width} ${vb.height}`);
}

function refit() {
  if (!state.activeSvg || !state.panZoom) return;
  const vb = deriveViewBox(state.activeSvg);
  state.panZoom.viewBox = { ...vb };
  applyViewBox(state.activeSvg, state.panZoom.viewBox);
}

document.addEventListener('keydown', event => {
  if (event.key.toLowerCase() === 'f') {
    refit();
  }
});

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}
